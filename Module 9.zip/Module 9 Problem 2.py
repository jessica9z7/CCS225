# Jessica Kusmierz
# 11/19/2025
# Problem 2

L = []
counter = 0

while counter <= 10:
    L.append(counter)
    counter += 1

print("List")