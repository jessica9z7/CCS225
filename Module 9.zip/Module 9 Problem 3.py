# Jessica Kusmierz
# 11/19/2025
# Problem 3

numbers = []

total_sum=0


while total <= 100:
    num = int(input("Enter a number: "))
    numbers.append(num)
    total += num

print("Numbers entered:", numbers)
print("Total sum:", total)