# Jessica Kusmierz
# 11/19/2025
# Problem 4

counter = 0
tens =[]
while counter <= 50:
    if counter % 10 == 0:
        tens.append(counter)
    counter += 1

print(tens)