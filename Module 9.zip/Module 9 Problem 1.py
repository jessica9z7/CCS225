# Jessica Kusmierz
# 11/19/2025
# Problem 1

while True:
    print("Infinite")